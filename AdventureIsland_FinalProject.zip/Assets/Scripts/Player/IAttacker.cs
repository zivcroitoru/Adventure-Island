public interface IAttacker
{
    void Attack();
    bool CanAttack();
}
