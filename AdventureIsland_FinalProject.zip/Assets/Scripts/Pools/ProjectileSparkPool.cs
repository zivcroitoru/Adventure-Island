public sealed class ProjectileSparkPool : ProjectilePool<ProjectileSpark> { }
