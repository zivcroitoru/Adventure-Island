public sealed class ProjectileBoomerangPool : ProjectilePool<ProjectileBoomerang> { }
