public sealed class ProjectileAxePool : ProjectilePool<ProjectileAxe> { }
