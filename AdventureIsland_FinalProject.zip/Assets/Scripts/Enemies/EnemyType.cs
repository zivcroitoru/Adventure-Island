public enum EnemyType
{
    Basic,
    Spider,
    Bird,
    Snake,
    SnakeShooter,
    Frog,
    Ghost
}
