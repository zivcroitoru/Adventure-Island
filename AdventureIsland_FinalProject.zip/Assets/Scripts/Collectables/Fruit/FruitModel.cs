public class FruitModel
{
    public int EnergyValue { get; private set; }

    public FruitModel(int energyValue)
    {
        EnergyValue = energyValue;
    }
}
