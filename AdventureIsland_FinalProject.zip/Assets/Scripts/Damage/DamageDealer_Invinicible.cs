using UnityEngine;

public class DamageDealer_Invinicible : MonoBehaviour, IDamageDealer
{
    [SerializeField] private int highDamage = 100; // High damage when dealing with the player
    [SerializeField] private bool destroyAfterHit = false;

    private IInvincible invincibleComponent;

    // This will reference the invincibility state of the player
    private void Awake()
    {
        invincibleComponent = GetComponent<IInvincible>(); // Get the invincible component on the player
    }

    public bool DestroyAfterHit
    {
        get => destroyAfterHit;
        set => destroyAfterHit = value;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Skip if the target is the same as the game object (self-damage)
        if (other.gameObject == gameObject) return;

        // Check if the player is invincible
        int amount = CalculateDamage(other.gameObject);

        // Deal damage if applicable
        Damage.Deal(amount, gameObject, other.gameObject);

    }

    public void DealDamage(GameObject target)
    {
        int amount = CalculateDamage(target);
        Damage.Deal(amount, gameObject, target);
    }

    public int CalculateDamage(GameObject target)
    {
        // Check if the player is invincible (this script is on the player)
        if (invincibleComponent != null && invincibleComponent.IsInvincible)
        {
            return 99; // No damage if the player is invincible
        }
        

        // If the player is not invincible, deal high damage
        return 0;
    }
}
