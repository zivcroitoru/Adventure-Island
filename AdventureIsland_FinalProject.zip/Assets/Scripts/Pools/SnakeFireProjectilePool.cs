public sealed class SnakeFireProjectilePool : ProjectilePool<SnakeFireProjectile> { }
