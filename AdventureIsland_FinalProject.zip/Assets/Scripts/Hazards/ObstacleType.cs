public enum ObstacleType
{
    Rock,
    Fire,
    Projectile,
    Enemy
}
