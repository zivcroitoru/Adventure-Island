public interface IInvincible
{
    bool IsInvincible { get; }
    void SetTemporaryInvincibility(bool state);
}
