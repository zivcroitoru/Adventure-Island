public sealed class ProjectileFirePool : ProjectilePool<ProjectileFire> { }
