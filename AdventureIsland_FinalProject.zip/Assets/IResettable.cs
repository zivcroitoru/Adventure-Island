public interface IResettable
{
    void ResetState();
}
