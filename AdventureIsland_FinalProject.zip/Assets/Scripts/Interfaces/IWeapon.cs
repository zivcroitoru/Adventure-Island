public interface IWeapon
{
void Equip();
void UnEquip();
void Attack();
bool CanAttack();
}
