// Assets/Scripts/Interfaces/IAttackStrategy.cs
public interface IAttackStrategy
{
    void Attack();
}
