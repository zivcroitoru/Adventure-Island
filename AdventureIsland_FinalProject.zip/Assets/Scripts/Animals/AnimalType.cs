public enum AnimalType
{
    Blue,
    Red,
    Green
}
